Autocorrect
A font that fixes your spelling.

Type a misspelling, the font shows the correct spelling.
Corrections work in lowercase, Sentence case, and ALL CAPS.
Works in most apps that support OpenType ligatures.

Based on Instrument Sans by Rodrigo Fuenzalida.
Designed by Michael Seh.
michaelsfonts.com

OFL 1.1 licensed. Free to use, modify, and redistribute.
